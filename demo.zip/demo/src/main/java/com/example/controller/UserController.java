package com.example.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @RequestMapping("/login")
    public String login(String usename,String password) {
        if("1".equals(usename) && "1".equals(password))
        return "main";
        else
            return "login";
    }

    @RequestMapping("/logout")
    public String logout() {
        System.out.println("logout success");
        return "logout success";
    }

}
